// 配置文件 - 使用环境变量
// 如果环境变量未设置，将使用默认值（开发环境）
// 生产环境请务必通过环境变量配置敏感信息

export default {
  doubaoApi: {
    baseUrl: process.env.DOUBAO_API_BASE_URL || 'https://api.chatfire.site/v1/chat/completions',
    apiKey: process.env.DOUBAO_API_KEY || 'sk-pzZXi9zXV9ERBJFrjAVV4WEMj6u7TcTLtoNUkRfefSrLxlid',
    model: process.env.DOUBAO_MODEL || 'doubao-1.5-vision-pro-250328',
    maxTokens: parseInt(process.env.DOUBAO_MAX_TOKENS || '1000'),
    temperature: parseFloat(process.env.DOUBAO_TEMPERATURE || '0.1')
  },
  storage: {
    prefix: process.env.STORAGE_PREFIX || 'drug_record:',
    indexPrefix: process.env.STORAGE_INDEX_PREFIX || 'drug_index:'
  }
}

